module.exports = {
    // ...其他配置
    devServer: {
      port: 8088, // 您想要设置的端口号
    },
  };